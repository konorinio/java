public class Dog extends Animal {
    String kolor;
    private int age;

    public Dog(String kolor, int wiek, String imie, int age) {
        this.kolor = kolor;
        this.wiek = wiek;
        this.imie = imie;
        this.age = age;
    }
}
