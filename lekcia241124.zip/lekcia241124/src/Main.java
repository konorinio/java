import java.util.ArrayList;
import java.util.Comparator;

public class Main {

    public static <T> void swap(T[] array, int a, int b){
        if(a > array.length || b > array.length){
            return;
        }
        else{
            T temp = array[a];
            array[a] = array[b];
            array[b] = temp;
        }
    }
// nie dziala poprawic to
    public static <T extends Comparable<T>> T minValue(T[] array){
        if(array.length == 0){
            return null;
        }
        else{
            T temp = array[0];
            for(int i = 1; i < array.length; i++){
                if(temp.compareTo(array[i]) > 0){
                    temp = array[i];
                }
            }
            return temp;
        }
    }

    public static <T extends Animal> T findMax(T element1, T element2){
        if(element1.wiek > element2.wiek){
            return element1;
        }
        else{
            return element2;
        }
    }

    public static void main(String[] args) {

//        Dog pies = new Dog("bordowy", 53, "Marcin");
//        Dog pies2 = new Dog("brudny fest", 153, "Grzegorz Gromek");

        Integer[] array = {5, 3, 7, 5, -745, 0, 232423, -343534534 ,435634, 1234,23,4,23,4 ,12,-2};
//        Box<String> box = new Box<String>();
//        box.setObiekt("p");
//        Box<String> box2 = new Box<String>();
//        box2.setObiekt("p");
//        System.out.println(box.isEqual(box.getObiekt(), box2.getObiekt()));
//
//        Counter<Integer> counter = new Counter<>();
//        counter.add(5);
//        counter.add(10);
//        System.out.println(counter.getCount());
//
//        Integer[] array = {1,2,3,4};
//        swap(array, 0, 3);
//        System.out.println(array[0]);
//        System.out.println(array[3]);
//        System.out.println(findMax(pies, pies2).kolor);
        //System.out.println(minValue(array));
    }
}