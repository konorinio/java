public record Address(String street, int houseNumber, String postalCode, String city) {
}
