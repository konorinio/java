import java.util.Arrays;

public class MusicAlbum {
    String title;
    String artist;
    double[] ratings;

    public MusicAlbum(String title, String artist, double[] ratings) {
        this.title = title;
        this.artist = artist;
        this.ratings = ratings;
    }

    //getery
    public String getTitle() {
        return title;
    }
    public String getArtist() {
        return artist;
    }
    public double[] getRatings() {
        return ratings;
    }

    //setery
    public void setTitle(String title) {
        this.title = title;
    }
    public void setArtist(String artist) {
        this.artist = artist;
    }

    public void setRatings(double[] ratings) {
        this.ratings = ratings;
    }



    public void addRating(double rating) {
        ratings = Arrays.copyOf(ratings, ratings.length + 1);
        ratings[ratings.length - 1] = rating;
    }

    public void remove(int numer){
        if(numer >= 0 && numer < ratings.length){
            double[] newRatings = new double[ratings.length - 1];
            for(int i = 0; i < newRatings.length; i++)
                for(int j = 0; j < newRatings.length; j++){
                if(i != numer){
                    newRatings[j++] = ratings[i];
                }
            }
            ratings = newRatings;
        }
    }

    //te smieszne
    @Override
    public String toString() {
        return title + " - " + artist + " - " + Arrays.toString(ratings);
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MusicAlbum that = (MusicAlbum) o;
        return title.equals(that.title) && artist.equals(that.artist) && Arrays.equals(ratings, that.ratings);
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(new Object[]{title, artist, Arrays.hashCode(ratings)});
    }
}
