import java.util.Objects;

public class Processor {
    double frequency;
    int cores;
    String manufacturer;

    public Processor(double frequency, int cores, String manufacturer) {
        this.frequency = frequency;
        this.cores = cores;
        this.manufacturer = manufacturer;
    }

    public double getFrequency() {
        return frequency;
    }
    public int getCores() {
        return cores;
    }
    public String getManufacturer() {
        return manufacturer;
    }
    public void setFrequency(double frequency) {
        this.frequency = frequency;
    }
    public void setCores(int cores) {
        this.cores = cores;
    }
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    @Override
    public String toString() {
        return "frequency: "+frequency+" cores: "+cores+" manufacturer: "+manufacturer+"";
    }

    @Override
    public boolean equals(Object obj) {
        return (this == obj);
    }

    @Override
    public int hashCode() {
        return Objects.hash(frequency, cores, manufacturer);
    }
}
