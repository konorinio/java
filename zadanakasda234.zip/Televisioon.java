public class Televisioon extends Electronics{
//    public void turnOn(){
//        System.out.println("Televisioon turned on");
//    }
}
