public record Person2(String name, int age) {
    public Person2 {
        if (age < 0) {
            age = 0;
        }
    }
}
