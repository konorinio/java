public record Car(String brand, String model, double fuelConsumptionPer100km) {
    public double fuelCost(double fuelPrice, double distance){
        double fuel = (fuelConsumptionPer100km / 100) * distance;
        return fuel * fuelPrice;
    }
}
