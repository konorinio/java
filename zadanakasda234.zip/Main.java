import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        BookDTO book1 = new BookDTO("Domino", "Kmicic", 99.99, 2023);
        BookDTO book2 = new BookDTO("Droga do sukcesu", "Marcin Najman", 59.99, 2012);


        Person person1 = new Person("Marcin", "Najman",
                new Address("Drogowa", 14, "14-400", "Olsztyn"));

        Person person2 = new Person("Marek", "Kajman",
                new Address("Szosowa", 41, "40-140", "Rzeszów"));

        System.out.println(book1);
        System.out.println(book2);
        System.out.println(person1);
        System.out.println(person2);

        Car car1 = new Car("Ford", "Fiesta", 7.5);
        double cost = car1.fuelCost(6.54, 20.0);
        System.out.println("Koszt podrozy: " + cost);

        Person2 person3 = new Person2("Karol", -2);
        Person2 person4 = new Person2("Stanisław", 2);

        System.out.println(person3);
        System.out.println(person4);

        BankAccount konto1 = new BankAccount("1234567890");
        BankAccount konto2 = new BankAccount("1234567891", 100.0);

        System.out.println(konto1);
        System.out.println(konto2);

        double[] ratings = {5.3, 7.1, 9.9};
        MusicAlbum peanits = new MusicAlbum("peanits", "wezer", ratings);
        //peanits.displayRating();
        peanits.addRating(9.5);
        //peanits.displayRating();
        RockAlbum peper = new RockAlbum("chili peper", "red hot", ratings, "super turbo dark death metal");
        //System.out.println(peper.title + peper.rockGenre);
        System.out.println(peper.toString());
        System.out.println(peper.hashCode());

    }
}