public class RockAlbum extends MusicAlbum{
    private String rockGenre;
    public RockAlbum(String title, String artist, double[] ratings, String rockGenre) {
        super(title, artist, ratings);
        this.rockGenre = rockGenre;
    }

    public String getRockGenre() {
        return rockGenre;
    }

    public void setRockGenre(String rockGenre) {
        this.rockGenre = rockGenre;
    }

    @Override
    public String toString() {
        return "Rock Album: " + rockGenre + super.toString();
    }

}
