import java.util.List;


public class Magazyn {
    private List<String> produkty;
    private int ilosc;

    public Magazyn(List<String> produkty, int ilosc){
        this.produkty = produkty;
        this.ilosc = ilosc;
    }

    public void WyswietlAsortyment(){
        System.out.println("Asortyment magazynu: " + produkty + ", Ilosc: " + ilosc);
    }
    public String getClasss() {return "Cześć jestem klasą" + this.getClass().getSimpleName();}

}
